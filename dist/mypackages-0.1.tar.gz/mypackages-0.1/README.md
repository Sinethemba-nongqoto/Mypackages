# Mypackage

This library was created by sinethemba with the help of EDSA as an example of how to publish your own Python package.

# How to install
...